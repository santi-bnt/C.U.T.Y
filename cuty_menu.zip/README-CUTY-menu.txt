C.U.T.Y - MENU TACTIL PARA RASPBERRY PI 5
=========================================

Requiere estos archivos EXISTENTES en /home/santi:
- cuty_wifi_panel.py: el panel Wi-Fi que ya funciona (con Ver/Ocultar)
- cuty_touch_calibration.json: calibración táctil validada
- waveshare35a y /dev/fb1: pantalla SPI funcionando

NO reemplazar ni modificar el panel Wi-Fi original.

INSTALACIÓN
===========
1. Copia estos tres archivos a /home/santi:
   cuty_launcher.py
   cuty-launcher.service
   cuty-install.sh

2. En terminal de la Raspberry:
   python3 -m py_compile ~/cuty_launcher.py
   sudo systemctl stop cuty-wifi-panel.service 2>/dev/null || true
   sudo python3 ~/cuty_launcher.py

3. Prueba menú, Internet, Terminal y cara C.U.T.Y.
   En la cara mantén presionada la pantalla 10 segundos para volver.
   Para salir del programa manual presiona Ctrl+C en la terminal HDMI.

4. Si todo funciona, activa inicio automático:
   bash ~/cuty-install.sh
   sudo reboot

COMPROBACIÓN
============
   sudo systemctl status cuty-launcher.service --no-pager
   sudo journalctl -u cuty-launcher.service -n 50 --no-pager

VOLVER AL PANEL ANTIGUO
=======================
   sudo systemctl disable --now cuty-launcher.service
   sudo systemctl enable --now cuty-wifi-panel.service

NOTAS
=====
- Internet = menú de Wi-Fi, IP y diagnóstico. Se reutiliza tu panel actual.
- Terminal = consola sencilla con teclado táctil para comandos que terminan.
  No es un terminal interactivo completo (nano/top/sudo interactivamente).
- C.U.T.Y = CARA DE DEMOSTRACIÓN. No controla aún los servos ni el audio.
- Al entrar al modo C.U.T.Y no hay botón de regreso visible.
- El panel debe funcionar sin conexión a Internet ni HDMI.
- "Conectado al Wi-Fi" no significa acceso a Internet: usa Diagnosticar.
