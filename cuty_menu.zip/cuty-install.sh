#!/bin/bash
set -euo pipefail
cd /home/santi
[[ -f cuty_launcher.py ]] || { echo 'Falta /home/santi/cuty_launcher.py'; exit 1; }
[[ -f cuty_wifi_panel.py ]] || { echo 'Falta /home/santi/cuty_wifi_panel.py'; exit 1; }
[[ -f cuty_touch_calibration.json ]] || { echo 'Falta la calibración táctil'; exit 1; }
python3 -m py_compile cuty_launcher.py cuty_wifi_panel.py
sudo systemctl disable --now cuty-wifi-panel.service 2>/dev/null || true
if [[ -f "$HOME/.config/autostart/cuty-mirror.desktop" ]]; then
    mv "$HOME/.config/autostart/cuty-mirror.desktop" "$HOME/.config/autostart/cuty-mirror.desktop.disabled"
fi
if [[ -f /etc/systemd/system/cuty-launcher.service ]]; then
    sudo cp /etc/systemd/system/cuty-launcher.service /etc/systemd/system/cuty-launcher.service.bak
fi
[[ -f cuty-launcher.service ]] || { echo 'Falta cuty-launcher.service'; exit 1; }
sudo cp cuty-launcher.service /etc/systemd/system/cuty-launcher.service
sudo systemctl daemon-reload
sudo systemctl enable --now cuty-launcher.service
sudo systemctl --no-pager --full status cuty-launcher.service
